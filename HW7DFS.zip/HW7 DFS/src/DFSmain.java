/*
 * Josh Sales
 * HW7 DFS
 * 333.001 Algorithms and Data Structures 
 * 4/21/2020
 */


public class DFSmain {

	/*
	 * For at least three different graphs of size >= 6 nodes, create the graph, perform the graph algorithm, 
	 * and display the results. (You'll need to write down a graph as a 2D array with true and false values, 
	 * before giving it as argument to a Graph constructor.)
	 */
	public static void main(String[] args) {				
		System.out.println("\n===================================Graph 1======================================");
		int rows=8;		 int colums= 8; 
		boolean [][]matrix = new boolean[rows][colums];//building a true/false matrix
		matrix[0][2] = true;  matrix[0][3] = true;  matrix[0][6] = true; 
		matrix[1][2] = true;  matrix[1][7] = true;
		matrix[2][0] = true;  matrix[2][1] = true;  
		matrix[3][0] = true;  matrix[3][5] = true;  matrix[3][6] = true;  
		matrix[4][5] = true;  
		matrix[5][3] = true;  matrix[5][4] = true;  matrix[5][7] = true; 
		matrix[6][0] = true;  matrix[6][3] = true;  
		matrix[7][1] = true;  matrix[7][5] = true;
		Graph mygraph = new Graph(matrix);
		
		mygraph.depthFirstSeach();
		mygraph.toString();
		System.out.println("\n===================================Graph 2======================================");
		
		int rows2=6;		 int colums2= 6; 
		boolean [][]matrix2 = new boolean[rows2][colums2];
		matrix2[0][1] = true;  matrix2[0][2] = true;  matrix2[0][5] = true;  
		matrix2[1][0] = true;  matrix2[1][5] = true;
		matrix2[2][0] = true;  matrix2[2][3] = true;  matrix2[2][4] = true;  
		matrix2[3][0] = true;  matrix2[3][5] = true;   
		matrix2[4][0] = true;  matrix2[4][2] = true;
		matrix2[5][1] = true;  matrix2[5][0] = true;  
		Graph mygraph2 = new Graph(matrix2);
		
		mygraph2.depthFirstSeach();
		mygraph2.toString();
		System.out.println("\n===================================Graph 3======================================");
		
		int rows3=11;		 int colums3= 11; 
		boolean [][]matrix3 = new boolean[rows3][colums3];
		matrix3[0][5] = true;  
		matrix3[1][3] = true;  matrix3[1][5] = true;  matrix3[1][6] = true;
		matrix3[2][4] = true;    
		matrix3[3][1] = true;  matrix3[3][10] = true;  
		matrix3[4][2] = true;  matrix3[4][7] = true; 
		matrix3[5][0] = true;  matrix3[5][1] = true;  matrix3[5][9] = true; 
		matrix3[6][1] = true;    
		matrix3[7][4] = true;  
		matrix3[8][10] = true; 
		matrix3[9][5] = true;  
		matrix3[10][3] = true;  matrix3[10][8] = true;
		Graph mygraph3 = new Graph(matrix3);
		
		mygraph3.depthFirstSeach();
		mygraph3.toString();

		
		

	}

}

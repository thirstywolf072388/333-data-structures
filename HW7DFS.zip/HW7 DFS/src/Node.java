
public class Node {
	
	private int name;		//name of node
	private int parent;		//parent node pointer	
	private int d;			//time stamp when visited
	private int f; 			//time stamp path closed
	private int color;		//Value 0 means the node is white / unvisited, 1 means gray, and 2 means black.

	
	//build a Node 
	public Node(int name) {
		this.name =name;
		setParent(-1);
		setD(0);
		setF(0);
		setColor(0);
	}
	
	//Detailed printout of Nodes information
	public String toString() {
		System.out.printf("Name: %d \tParent: %d\tD: %d\tF: %d\tColor: %d", 
							this.name, this.parent, this.d, this.f, this.color);
		return null;
		
	}

	public int getName() {
		return name;
	}

	public int getParent() {
		return parent;
	}

	public void setParent(int parent) {
		this.parent = parent;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}
	
}


public class Graph {

	// =========================Data
	// fields===========================================

	private int n; // number of nodes in the graph
	// Starts at 0. Increment and assign from this data field, to set a time stamp
	// during a depth first search.
	private int time;
	private Node[] nodes; // an array of Node objects. This stores augmented information about every node
							// in the graph.

	/*
	 * a 2d boolean array. This is an adjacency matrix storing edge information /
	 * neighbors of every node. (So, entry (i,j) being true or false tells you
	 * whether or not node i has an edge to node j.)
	 */
	private boolean[][] edges;

	// ==========================Methods===============================================

	/*
	 * A constructor with a 2d boolean array parameter. The parameter should be
	 * assigned to edges data field, and its length should be assigned to n.
	 * Initialize time to 0. Allocate the nodes array as a length n array of Node
	 * handles, then use a loop to iterate through the nodes and assign each one a
	 * newly constructed Node object. (A node's index in the nodes array is also its
	 * name, so node 6 is the one at index 6.)
	 */
	public Graph(boolean[][] array) {
		n = array.length;
		edges = new boolean[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				edges[i][j] = array[i][j];
			}
		}
		time = 0;
		nodes = new Node[n];
		for (int i = 0; i < n; i++) {
			nodes[i] = new Node(i);
		}
	}

	/*
	 * A public method depthFirstSearch with no parameters. Your Node class
	 * constructor already initialized all the nodes, so you don't have to do that
	 * again from the pseudocode .(To see if a node is white, look at one of the
	 * Node objects in the nodes array, and invoke its color getter method.)
	 */
	public void depthFirstSeach() {
		for (int i = 0; i < n; i++) {
			Node u = nodes[i];
			if (u.getColor() == 0) {
				dfsVisit(u);
			}
		}
	}

	/*
	 * A private helper method dfsVisit with one parameter u for the node to start
	 * from. (To iterate through the neighbors of some node j, go through row j of
	 * the edges array, and each entry that's true is a neighbor.)
	 */
	private void dfsVisit(Node u) {
		time++;
		u.setD(time); // set discover time
		u.setColor(1); // set to grey
		int curNodenName = u.getName();
		for (int i = 0; i < n; i++) {
			boolean isanEdge = edges[curNodenName][i];//is the edge true?
			Node v = nodes[i]; // current neighbor node

			if (isanEdge == true && v.getColor() == 0) { // if v is true and white set u parent and visit v
				v.setParent(u.getName());
				dfsVisit(v);
			}
		}
		u.setColor(2);
		time++;
		u.setF(time);
	}

	/*
	 * A toString method to return a string describing the graph, or a print method
	 * to print it out directly. This should include the entire contents of the
	 * edges adjacency matrix 2d array. Also you should use a loop to go through a
	 * loop of the nodes using its toString method.
	 */
	public String toString() {
		printmatrix();
		nodeInfo();
		
		return null;
	}

	private void printmatrix() {
		// matrix true/false table build
		System.out.print("\n===============True/False Matrix===============\n");
		for (int a = 0; a < n; a++) {
			System.out.printf("\t%d", a);
		}
		for (int i = 0; i < n; i++) { // row
			System.out.print("\n");
			System.out.printf("%d  ", i);
			for (int j = 0; j < n; j++) { // col
				System.out.printf("\t%s", edges[i][j]);
			}
		}
	}

	private void nodeInfo() {
		// print each node in the nodes array
		System.out.println("\n===============Node Info===============");
		for (int i = 0; i < n; i++) {
			Node a = nodes[i];
			a.toString();
			System.out.print("\n");
		}		
	}

	
}

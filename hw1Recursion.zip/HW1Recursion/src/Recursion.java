/**
 * @author Josh Sales
 *1/21/2020
 *CSCI 333.001
 *HW1 Recursion
 */
public class Recursion {
	
	/**
	 * A search that breaks your sorted int array into 3 smaller recursive problems to solve
	 * set your lower and upper bounds to break apart the array
	 * @param myARRAY- an array that is given
	 * @param findNum- Number that your trying to find in the array
	 * @param start- starting index
	 * @param end- ending index
	 * @return- returns the index where the first term that is searched for is found
	 */
	static int trinarySearch(int [] myARRAY, int findNum, int start, int end) {		
		//if array is too small
		if(myARRAY.length == 0)
			return -1;
		
		//base case if your array is smaller than 3 number return the index
		if(end-start<3) {
			for(int i= start; i<end; i++) {
				if(myARRAY[i]== findNum)  
					return i;				
			}
			return -1;
		}		
		else {
			int lowBound = start + (end-start)/3;
			int upperBound = end - (end-1)/3;
			
			//if the lowBound index is the number your looking for you found it. 
			//Now look to the left in the array if thats your number too check recursively to the left for its first occurrence
			if(myARRAY[lowBound] == findNum) {
				if(myARRAY[lowBound-1] == findNum) 
					return trinarySearch(myARRAY, findNum,start,lowBound-1);
							
				return lowBound;
			}
			
			//if the upperbound index is the number your looking for you found it. 
			//Now look to the left in the array if thats your number too check recursively to the left for its first occurrence 
			if(myARRAY[upperBound] == findNum) {
				if(myARRAY[upperBound-1] == findNum) 
					return trinarySearch(myARRAY, findNum,lowBound,upperBound-1);
				
				return upperBound;
			}
			
			//if the number your looking for is smaller than the lowerBound search here
			if (findNum < myARRAY[lowBound]) 
				return trinarySearch(myARRAY, findNum,start,lowBound);
			
			//if the number your looking for is larger than the lowerBound search here
			if(findNum>myARRAY[upperBound])
				return trinarySearch(myARRAY, findNum,upperBound,end);
			
			//search in the middle
			return trinarySearch(myARRAY, findNum,lowBound,upperBound);
			}		
	}	
	
	public static void main(String[] args) {
		System.out.print("Basic array to check for correct index:\t\t\t   ");
		int myArray1 [] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		System.out.println(trinarySearch(myArray1, 15, 0, 20));
		
		System.out.print("Check for empty Array:\t\t\t\t\t  ");
		int myArray2 [] = {};
		System.out.println(trinarySearch(myArray2, 2, 0, 10));		
		
		int myArray3 [] = {12,34,45,56,77,111,111,111,111,133};
		System.out.print("HighBound number but the first occurence index is:\t   ");
		System.out.println(trinarySearch(myArray3, 111, 0, 10));		
		
		//?????????????????????????place 13 at the first 33 and it goes -1
		int myArray4 [] = {12,33,33,33,33,33,99,111,122,133};
		System.out.print("LowBound number but the first occurence index is:\t   ");
		System.out.println(trinarySearch(myArray4, 33, 0, 10));
		
		System.out.print("Basic numbers to check for correct index:\t\t   ");
		int myArray5 [] = {11,23,34,45,56,67,78,89,92,99,113,132,143,164,195};
		System.out.println(trinarySearch(myArray5, 33, 0, 15));
		
	}

}

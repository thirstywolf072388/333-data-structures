
public class OpenAddressedHashTable {
	static final int DELETED = Integer.MIN_VALUE;
	static final double A = 0.6180339887;
	private Integer[] table;
	private int m;
	
	//constructor make an array
	public OpenAddressedHashTable(int n) {
		m = n*2;
		table = new Integer[m];
	}
	
	//insert x in the table at location j
	public int insert(int x) {
		int key = x;
		for(int i = 0; i<m-1; i++) {
			int j = hash(key,i);
			if (table[j] == null || table[j] == DELETED) {//if its null or deleted your can place x here
				table[j] = x;
				return j;
			}
		}
		System.out.print("Hash table overflow.");
		return -1;
		
	}
	
	//place a delete in the key location if it matches
	public int delete(int x) {
		int key = x;
		for(int i = 0; i<m-1; i++) {
			int j = hash(key, i);
			if(table[j] == key) {
				table[j] = DELETED;
				return j;
			}
		}
		System.out.print("Element not found.");
		return -1;
	}
	
	//find if k is in your hash table or not 
	public Object search(int k) {
		for(int i = 0; i<m-1; i++) {
			int j = hash(k, i);
			if(table[j] == null) {
				return null;
			}
			if(table[j] == k) {
				return table[j];
			}
		}
		return null;
	}
	
	public void printTable() {
		String printtable = "Open Address Table Contains\n";
		for(int i=0; i<m; i++) {			
			printtable +=  "Index "+ i+" " + table[i] +"\n";
		}		 
		System.out.printf(printtable);
	}
	
	//Hash function
	private int hash(int key) {
		int index = (int) (m*(key*A %1));
		return index;
	}
	//Hash function
	private int hash(int key, int index) {
		int tableListIndex = ((key+index)%m);
		return tableListIndex;
	}
}

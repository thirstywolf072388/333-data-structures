import java.util.LinkedList;

public class ChainedHashTable {

	static final double A = 0.6180339887;
	private int m;
	private LinkedList<Integer>[] table;
	
	//constructor of an array of linked list
	public ChainedHashTable(int n) {
		m = n*2;
		table = new LinkedList[m];
		for(int i=0; i<m; i++) {	
			table[i]= new LinkedList<Integer>();
		}		
	}
	
	public void insert(int x) {
		//insert x at the head of linked list T[h(x.key)]		
		table[hash(x)].add(x);	
		//Testing
		//int num = hash(x);
		//System.out.printf("inserted %d at table index %d",x,num);
		//System.out.printf(" number %d\n",table[hash(x)].indexOf(x));
	}
	
	public void delete(int x) {
		//delete x from linked list T[h(x.key)]
		int index = table[hash(x)].indexOf(x);
		table[hash(x)].remove(index);
		
			
	}

	//Search for x and return its key and linked list location
	public int search(int x) {
		int lookingfor = table[hash(x)].indexOf(x);
		int hashval = hash(x);
		System.out.printf("Value %d is at Table Index %d Linked List Index %d\n",x, hashval,lookingfor);
		return 	lookingfor;
	}
	
	public void printTable() {
		String printtable = "Table contains\n";
		for(int i=0; i<m; i++) {			
			printtable += "Table linked list index " + i + table[i].toString() +"\n";
		}		 
		System.out.printf(printtable);
	}
	
	private int hash(int key) {
		int index = (int) (m*(key*A %1));
		return index;
	}
}

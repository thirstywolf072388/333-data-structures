/**
 * @author Josh Sales
 *3/1/2020
 *CSCI 333.001
 *HW5 Hashing
 */

public class hw5main {
	
	public static void main(String[] args) {
		
		ChainedHashTable hashTable = new ChainedHashTable(20);
		System.out.print("=====================Chain Hash Before Deletions====================\n");
		for(int i =0; i<=40;i++) {
			hashTable.insert(33+i);
		}
		hashTable.printTable();
		System.out.print("=====================After Deletions=====================\n");
		System.out.print("Deleting: 34,35,42\n");
		hashTable.delete(42);
		hashTable.delete(35);
		hashTable.delete(34);
		hashTable.printTable();
		System.out.print("=====================Search==============================\n");
		//search for and found
		hashTable.search(61);
		hashTable.search(49);
		hashTable.search(72);
		hashTable.search(43);
		hashTable.search(48);
		
		//not found
		hashTable.search(34);//deleted
		hashTable.search(42);//deleted
		hashTable.search(100);
		hashTable.search(0);
		hashTable.search(200);
		
		
		System.out.print("\n\n\n=====================OpenAddressedHashTable====================\n\n\n");

		OpenAddressedHashTable addresstable= new OpenAddressedHashTable(20);
		System.out.print("=====================Before Deletions==========================\n");
		for(int i =0; i<35; i++) {
			addresstable.insert(i+23);
		}
		addresstable.printTable();
		
		System.out.print("=====================After Deletions==========================\n");
		System.out.print("Deleting: 23,27,29,31\n");		
		addresstable.delete(23);
		addresstable.delete(27);
		addresstable.delete(29);
		addresstable.delete(31);//delete this value
		addresstable.printTable();
		
		System.out.print("=====================Searching================================\n");		
		System.out.printf("Searching for 2 return is %d\n",addresstable.search(2));
		System.out.printf("Searching for 27 return is %d\n",addresstable.search(27));
		System.out.printf("Searching for 999 return is %d\n",addresstable.search(999));
		System.out.printf("Searching for 29 return is %d\n",addresstable.search(29));
		System.out.printf("Searching for 20 return is %d\n",addresstable.search(20));
		System.out.printf("Searching for 40 return is %d\n",addresstable.search(40));
		System.out.printf("Searching for 38 return is %d\n",addresstable.search(38));
		System.out.printf("Searching for 42 return is %d\n",addresstable.search(42));
		System.out.printf("Searching for 34 return is %d\n",addresstable.search(34));
		System.out.printf("Searching for 24 return is %d\n",addresstable.search(24));

		

	}
}
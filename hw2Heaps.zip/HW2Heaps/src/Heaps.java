
public class Heaps {
	
	public static String toString(int []ary) {
		String copy = "Original Heap\t";
		int length = ary.length;
		for(int i = 0;i<length; i++) {
			copy += ary[i]+" "; 
		}
		return copy;		
	}

	
	/*
	 *  Its purpose is to create some MaxHeap objects and test them.  
	 *  (Bear in mind that the only public methods of MaxHeap are the constructor, printMaxHeap, 
	 *  and heapsort.) Use at least 5 different arrays filled with values to make at least 5 different 
	 *  MaxHeap objects. For each object:
	 *  
	 *  Print out the original array that it was constructed from -- the one with values in arbitrary 
	 *  order. Use the java.util.Arrays.toString method.
	 *  Print out the heap with printMaxHeap. By looking at the console it should be obvious the 
	 *  values are rearranged, from the buildMaxHeap that was invoked in the constructor.
	 *  Invoke heapsort.
	 *  Print out the heap again with printMaxHeap. In the console you should notice all 
	 *  the values are sorted.
	 */
	public static void main(String[] args) {			
	
		int [] myArray1 = {60,10,50,40,100,30,20};//original array
		MaxHeap array1 = new MaxHeap(myArray1);//constructor call to maxheap
		System.out.println(toString(myArray1));	//print array in original unsorted order	
		System.out.print("buildMaxHeap\t");
		System.out.println(array1.printMaxHeap());//print build heap constructor array
		array1.heapsort();//sort it 
		System.out.print("Heapsort heap\t");
		System.out.println(array1.printMaxHeap());//print array in increasing order
		System.out.print("\n");
		
		int [] myArray2 = {12,87,77,24,66,102,74,44,99,1,45,66,85};
		MaxHeap array2 = new MaxHeap(myArray2);
		System.out.println(toString(myArray2));		
		System.out.print("buildMaxHeap\t");
		System.out.println(array2.printMaxHeap());
		array2.heapsort();
		System.out.print("Heapsort heap\t");
		System.out.println(array2.printMaxHeap());
		System.out.print("\n");
				
		int [] myArray3 = {45,88,96,35,20,42,74};
		MaxHeap array3 = new MaxHeap(myArray3);
		System.out.println(toString(myArray3));		
		System.out.print("buildMaxHeap\t");
		System.out.println(array3.printMaxHeap());
		array3.heapsort();
		System.out.print("Heapsort heap\t");
		System.out.println(array3.printMaxHeap());
		System.out.print("\n");		
		
		int [] myArray4 = {99,147,55,79,22,13,4,67};
		MaxHeap array4 = new MaxHeap(myArray4);
		System.out.println(toString(myArray4));		
		System.out.print("buildMaxHeap\t");
		System.out.println(array4.printMaxHeap());
		array4.heapsort();
		System.out.print("Heapsort heap\t");
		System.out.println(array4.printMaxHeap());
		System.out.print("\n");		
		
		int [] myArray5 = {88,74,63,12,222,35,41,11,78,95,62,111,300};
		MaxHeap array5 = new MaxHeap(myArray5);
		System.out.println(toString(myArray5));		
		System.out.print("buildMaxHeap\t");
		System.out.println(array5.printMaxHeap());
		array5.heapsort();
		System.out.print("Heapsort heap\t");
		System.out.println(array5.printMaxHeap());
		System.out.print("\n");				
	
	}

}

import java.util.Arrays;
public class MaxHeap {

	private int myheap[];
	private int heapsize;
		

	// Constructor that checks the size and makes a copy of the array to heap sort
	public MaxHeap(int [] inputArray) {
		heapsize = inputArray.length;
		myheap = Arrays.copyOfRange(inputArray, 0, heapsize);
		buildMaxHeap();		
	}
	
	//checks the index of the node and tells where the child is in the array
	private int leftChildOf(int index) {
		if(index > heapsize)
			return -1;		
		if(2*index > heapsize)
			return -1;
		return 2*index;
	}
	
	////checks the index of the node and tells where the child is in the array
	private int rightChildOf(int index) {
		if(index > heapsize)
			return -1;
		if(2*index+1 > heapsize)
			return -1;
		return 2*index+1;
		
	}
	
	//prints your heap array
	public String printMaxHeap() {
		 
		String printThis = "";
		for(int i = 0; i<heapsize; i++) {
			printThis += myheap[i] +" "; 
		}
		return printThis;		
	}

	//get your left and right children see if they are bigger than the 
	//parent if so change them and recursively check that larger index 
	private void maxHeapify(int index){
		int left = leftChildOf(index);
		int right = rightChildOf(index);
		int largest = 0;
		
		
		if(left!=-1 && left <= heapsize && myheap[left-1] > myheap[index-1])//if left child is larger than the parent largest = left child
			largest = left;
		else 
			largest = index; //parent is larger
		
		if(right!= -1 && right <= heapsize && myheap[right-1] > myheap[largest-1])//if right child is larger than the parent largest = right child
			largest = right;
		
		if(largest != index) {
			int temp = myheap[index-1];
			myheap[index-1] = myheap[largest-1];
			myheap[largest-1] = temp;			
			maxHeapify(largest);
			
		}		
	}
	
	//half of the heap are leaves so loop through the internal nodes
	private void buildMaxHeap() {	
		for(int i = (heapsize/2); i > 0; i--) {
			maxHeapify(i);
		}		
	}
	
	//after you have sifted the larger nodes to the top of heap 
	//Remove the root node and put at the end of the array then omit it from the array
	//after entire heap has be sorted restore the heapsize
	public void heapsort() {		
		buildMaxHeap();
		int copyheapSize = heapsize;
		for(int i = heapsize; i > 0;) {
			int temp = myheap[0];
			myheap[0] = myheap[i-1];
			myheap[i-1] = temp;			
			i--;
			this.heapsize--;
			maxHeapify(1); 
		}
		heapsize = copyheapSize;
	}
}

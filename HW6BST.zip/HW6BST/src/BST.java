/**
 * @author Josh Sales
 *3/24/2020
 *CSCI 333.001
 *HW6 BST
 */
public class BST {

	public static void main(String[] args) {
		BinarySearchTree tree = new BinarySearchTree();
				
		BSTNode a = new BSTNode(45);
		BSTNode b = new BSTNode(32);
		BSTNode c = new BSTNode(1);
		BSTNode d = new BSTNode(67);
		BSTNode e = new BSTNode(98);
		BSTNode f = new BSTNode(64);
		BSTNode g = new BSTNode(27);
		BSTNode h = new BSTNode(99);
		BSTNode i = new BSTNode(22);
		BSTNode j = new BSTNode(99);
		BSTNode k = new BSTNode(26);
		BSTNode l = new BSTNode(63);
		BSTNode m = new BSTNode(88);
		BSTNode n = new BSTNode(0);
		BSTNode o = new BSTNode(30);
		BSTNode p = new BSTNode(48);
		BSTNode q = new BSTNode(21);
		BSTNode r = new BSTNode(92);
		BSTNode s = new BSTNode(27);
		BSTNode t = new BSTNode(18);
		
		tree.Insert(a);	
		tree.Insert(b);	
		tree.Insert(c);
		tree.Insert(d);	
		tree.Insert(e);	
		tree.Insert(f);	
		tree.Insert(g);	
		tree.Insert(h);	
		tree.Insert(i);
		tree.Insert(j);	
		tree.Insert(k);	
		tree.Insert(l);	
		tree.Insert(m);
		tree.Insert(n);	
		tree.Insert(o);	
		tree.Insert(p);	
		tree.Insert(q);	
		tree.Insert(r);	
		tree.Insert(s);
		tree.Insert(t);
		
		System.out.println("Tree Size:\t " + tree.getSize());		
		System.out.print("Preorder:\t ");
		tree.preORDER();		
		System.out.print("Inorder:\t ");
		tree.inORDER();
		System.out.print("Postorder:\t ");
		tree.postORDER();
		
		//in tree
		System.out.println("\nSearch for 45:\t " + tree.Search(45));
		System.out.println("Search for 99:\t " + tree.Search(99));
		System.out.println("Search for 0:\t " + tree.Search(0));
		System.out.println("Search for 18:\t " + tree.Search(18));
		System.out.println("Search for 48:\t " + tree.Search(48) + "\n");
		
		//not in tree
		System.out.println("Search for 3:\t " + tree.Search(3));
		System.out.println("Search for 100:\t " + tree.Search(100));
		System.out.println("Search for 23:\t " + tree.Search(23));
		System.out.println("Search for 46:\t " + tree.Search(46));
		System.out.println("Search for 97:\t " + tree.Search(97)+"\n");
		
		//delete
		tree.Delete(k);//26
		tree.Delete(b);//32
		tree.Delete(e);//98
		tree.Delete(j);//99
		tree.Delete(r);//92
		System.out.printf("Delete %d,%d,%d,%d,%d \n\n",k.getKey(),b.getKey(),e.getKey(),j.getKey(),r.getKey());
		
		System.out.println("Tree Size:\t " + tree.getSize());
		System.out.print("Inorder:\t ");
		tree.inORDER();
		
		System.out.println("Max is: " +tree.Maximum(a));
		System.out.println("Min is: " +tree.Minimum(a));
		
		System.out.printf("%d's Succesor is "+ tree.Succsessor(o)+"\n" ,o.getKey());
		System.out.printf("%d's Predecessor is "+ tree.Predecessor(o)+"\n" ,o.getKey());
	}
}

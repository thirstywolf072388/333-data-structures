
public class BinarySearchTree {
	
	private BSTNode root = null;
	private int size = 0;
	
	public BinarySearchTree() {
		root = null;
		size = 0;
	}

	public int getSize() {
		return size;
	}
	
	
	private void transplant(BSTNode oldnode, BSTNode newnode) {				
		//if the oldnodes parent is null the trees new root is the newnode
		if(oldnode.getP() == null) 
			root = newnode;
		
		//if the oldnode was the left child of its parent then set parents left child to newnode
		else if(oldnode == oldnode.getP().getLeft()) 
			oldnode.getP().setLeft(newnode); 
		
		else
			oldnode.getP().setRight(newnode);
		
		if (newnode != null)
			newnode.setP(oldnode.getP());
	}
	
	//given the rootnode of the BST and a key check to see if node is there
	private BSTNode search(BSTNode rootnode, int key) {
		if(rootnode == null) 								//base case: empty subtree		
			return null;
				
		if(key == rootnode.getKey()) 						//base case: key is at subtree root			
			return rootnode;
		
		if(key < rootnode.getKey()) 							//recursive case: left subtree
			return search(rootnode.getLeft(), key);
		else										//recursive case: right subtree
			return search(rootnode.getRight(), key);
	}
	
	//keep checking the left node to see what is the smallest child
	private BSTNode minimum(BSTNode x) {
		while(x.getLeft() != null) {
			x = x.getLeft();
		}
		return x;
	}
	
	//keep checking the right node to see what is the largest child
	private BSTNode maximum(BSTNode x) {
		while(x.getRight() != null) {
			x = x.getRight();
		}
		return x;
	}
	
	//find the the next largest number or check the minimum of your nodes right subtree
	private BSTNode successor(BSTNode x) {
		if(x.getRight() != null) //if it has a right child check the smallest in that subtree
			return minimum(x.getRight());
				
		while(x.getP() != null && x == x.getP().getRight()) {
			x = x.getP();
		}
		return x.getP();
	}
	
	//check the maximum of your nodes left subtree
	private BSTNode predecessor(BSTNode x) {
		if(x.getLeft() != null)
			return maximum(x.getLeft());
		while(x.getP() != null && x == x.getP().getLeft()) {
			x = x.getP();
		}
		return x.getP();
	}

	//add a node to your BSTree
	private void insert(BSTNode z) {		
		BSTNode y = null;//trailing pointer to the parent node of current x
		BSTNode x = this.root;
		
		while(x != null) {//move down the tree one level per iteration
			y = x;
		if(z.getKey()< x.getKey())//go left: if your current node is smaller than the prev
			x = x.getLeft();
		else
			x = x.getRight();//go right
		}
		
		z.setP(y);
		
		if(y == null)// if the tree was empty z is the new root of the tree
			this.root = z;
		else if(z.getKey() < y.getKey())//z's parent is y so set y's childrent to z
			y.setLeft(z);//left child
		else
			y.setRight(z);//right child
		size++;		
	}
	
	//remove node from tree
	private void delete(BSTNode z) {
		BSTNode y;	
		if(z.getLeft() == null)
			transplant(z,z.getRight());
		else if(z.getRight() ==null)
			transplant(z,z.getLeft());
		else {
			y = minimum(z.getRight());
			if(y.getP() != z) {
				transplant(y,y.getRight());
				y.setRight(z.getRight());
				y.getRight().setP(y);
			}
			transplant(z,y);
			y.setLeft(z.getLeft());
			y.getLeft().setP(y);
		}		
		size--;	
	}
	
	
	//Wrapper methods
	public BSTNode Search(int key) {
		BSTNode tree = root;
		return search(tree,key);
	}	
	public int Minimum(BSTNode x) {		
		int i = minimum(x).getKey();
		return i;
	}	
	public int Maximum(BSTNode x) {
		int i = maximum(x).getKey();
		return i;
	}
	public int Succsessor(BSTNode x) {	
		int i = successor(x).getKey();
		return i;
	}	
	public int Predecessor(BSTNode x) {		
		int i = predecessor(x).getKey();
		return i;
	}	
	public void Insert(BSTNode x) {		
		insert(x);
	}	
	public void Delete(BSTNode x) {		
		delete(x);
	}
		
	// prints as the line comes along the left side of each node in the drawing traversal 
	private void preOrder(BSTNode x) {
		if(x != null) {
			System.out.print(x.getKey() + " ");
			preOrder(x.getLeft());
			preOrder(x.getRight());
		}
	}
	
	// prints as the line comes along the bottome of each node in the drawing traversal 
	private void inOrder(BSTNode x) {
		if(x != null) {
			inOrder(x.getLeft());
			System.out.print(x.getKey() + " ");
			inOrder(x.getRight());
		}
	}
	
	// prints as the line comes along the right side of each node in the drawing traversal 
	private void postOrder(BSTNode x) {
		if(x != null) {
			postOrder(x.getLeft());
			postOrder(x.getRight());
			System.out.print(x.getKey() + " ");
		}
	}
	
	//ordered traversal wrappers
	public void preORDER() {		
		BSTNode x = this.root;
		preOrder(x);
		System.out.print("\n");
	}
	public void inORDER() {		
		BSTNode x = this.root;
		inOrder(x);
		System.out.print("\n");
	}
	public void postORDER() {		
		BSTNode x = this.root;
		postOrder(x);
		System.out.print("\n");
	}	
}

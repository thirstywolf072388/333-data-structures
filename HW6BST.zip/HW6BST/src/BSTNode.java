
public class BSTNode {

	private BSTNode p = null;
	private BSTNode left = null;
	private BSTNode right = null;
	private int key;
	
	//Implement a constructor method with a key parameter. It will set p left and right to NULL, 
	//and key to the constructor parameter.
	public BSTNode(int key) {
		p = left;
		right = null;
		this.key = key;
	}

	//Getter and setter methods
	public BSTNode getP() {
		return p;
	}

	public void setP(BSTNode p) {
		this.p = p;
	}

	public BSTNode getLeft() {
		return left;
	}

	public void setLeft(BSTNode left) {
		this.left = left;
	}

	public BSTNode getRight() {
		return right;
	}

	public void setRight(BSTNode right) {
		this.right = right;
	}

	public int getKey() {
		return key;
	}
	
}

/**
 * @author Josh Sales
 *2/10/2020
 *CSCI 333.001
 *HW3 QuickSort
 */
import java.util.Random;

public class QuickSort {

	//1)inclusive upper bound quicksort
	//quick sort with the right most element as the pivot
	public static void quicksort(int[]array, int start, int end){
		if(start < end) {
			int q = partition(array, start, end);//q is the pivot to be used in quicksort
			quicksort(array, start, q-1);//the first halve of sub problem
			quicksort(array, q+1, end);//the second halve of sub problem
		}
	}
	
	//takes the last element and moves all smaller to the left in the array
	private static int partition(int[]array, int start, int end) {
		int x = array[end];
		int i = start-1;//index to be switched with larger
		
		//loop to compare pivot to array elements and switch if smaller
		for(int j = start; j<=end-1;j++) {
			if(array[j]< x) {
				i = i + 1;
				int temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}						
		}
		//move the pivot to the middle/where its supposed to be in order
		int temp = array[i+1];
		array[i+1] = array[end];
		array[end] = temp;
		return i + 1;		
	}
	
	//same thing as quicksort but with a random partition that randomly picks the pivot
	public static void randomizedQuicksort(int[]array, int start, int end){		
		if(start < end) {		
			int q = randomizedpartition(array, start, end);
			randomizedQuicksort(array, start, q-1);
			randomizedQuicksort(array, q+1, end);
		}
	}
	
	// Get a random index number and swap it with the right most index in the array
	// random number index value is the pivot
	public static int randomizedpartition(int[]array, int start, int end){
		Random ran = new Random();
		int rando = ran.nextInt(end-start)+start;
		int temp = array[end];//save the last element
		array[end] = array[rando];//your new pivot
		array[rando] = temp;//place the last element here
		return partition(array,start,end);
			}
	
	//toString method to print each index in the array
	public static String toString(int []ary) {
		String copy = "";
		int length = ary.length;
		for(int i = 0;i<length; i++) {
			copy += ary[i]+" "; 
		}
		return copy;		
	}
	
	//Testing multiple arrays
	public static void main(String[] args) {
		int [] array1 = {22,55,33,88,11,77,22,43,57,12,11};
		System.out.println("Original Array\t"+toString(array1));
		quicksort(array1,0,array1.length-1);
		System.out.println("After QuickSort\t"+toString(array1));
		
		int [] array2 = {0,1,2,3,4,5,6};
		System.out.println("\nOriginal Array\t"+toString(array2));
		quicksort(array2,0,array2.length-1);
		System.out.println("After QuickSort\t"+toString(array2));
		
		int [] array3 = {4,7,77,85,42,36,20,1,0,0,18,56};
		System.out.println("\nOriginal Array\t"+toString(array3));
		quicksort(array3,0,array3.length-1);
		System.out.println("After QuickSort\t"+toString(array3));
		
		int [] array4 = {8,99,6,111,452,236,97,45,14,11,22};
		System.out.println("\nOriginal Array\t"+toString(array4));
		quicksort(array4,0,array4.length-1);
		System.out.println("After QuickSort\t"+toString(array4));
		
		int [] array5 = {77};
		System.out.println("\nOriginal Array\t"+toString(array5));
		quicksort(array5,0,array5.length-1);
		System.out.println("After QuickSort\t"+toString(array5));
		
		int [] rando1 = {23,34,87,94,55,33,88,11,77};
		System.out.println("\nOriginal Array\t\t"+toString(rando1));
		randomizedQuicksort(rando1,0,rando1.length-1);
		System.out.println("After Random QuickSort\t"+toString(rando1));
		
		int [] rando2 = {9,8,7,6,5,4,3,2,1,0};
		System.out.println("\nOriginal Array\t\t"+toString(rando2));
		randomizedQuicksort(rando2,0,rando2.length-1);
		System.out.println("After Random QuickSort\t"+toString(rando2));
		
		int [] rando3 = {1,88,77,21,36,0,54,78};
		System.out.println("\nOriginal Array\t\t"+toString(rando3));
		randomizedQuicksort(rando3,0,rando3.length-1);
		System.out.println("After Random QuickSort\t"+toString(rando3));
		
		int [] rando4 = {99,75,8183,687,42,58,6,2};
		System.out.println("\nOriginal Array\t\t"+toString(rando4));
		randomizedQuicksort(rando4,0,rando4.length-1);
		System.out.println("After Random QuickSort\t"+toString(rando4));
		
		int [] rando5 = {22,515,33,66,43,25,73,19,88,111,77};
		System.out.println("\nOriginal Array\t\t"+toString(rando5));
		randomizedQuicksort(rando5,0,rando5.length-1);
		System.out.println("After Random QuickSort\t"+toString(rando5));

	}

}

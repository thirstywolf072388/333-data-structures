/**
 * @author Josh Sales
 *2/19/2020
 *CSCI 333.001
 *HW4 RamSortnSelect
 */
import java.util.Arrays;
import java.util.Random;

public class HW4SortnSelect {

	public static void countingSort(int[] a,int[]b,int k) {
		int [] c = new int[k+1];
		for (int i = 0; i<=k; i++) {
			c[i] = 0;
		}
		//tally up each occurrence of each value in the input array and +1 to c array
		int asize = a.length;
		for (int i=0; i<asize; i++) {
			c[a[i]]++;
		}
		for(int i =1; i<=k;i++) {
			c[i] = c[i] +c[i-1];
		}
		//print each index from a.leng-1 to 0 in ary a to b using 
		//c to reference the index placement in ary b 
		for(int i=asize-1; i>=0; i--) {	
			b[c[a[i]]-1] = a[i];// needs the -1 to reference the zero index ary C
			c[a[i]]--;		
			//testing
			//System.out.println("TESTB\t"+toString(b));
			//System.out.println("TESTC\t"+toString(c));
		}
	}
	
	public static int randomizedQuickselect(int[]a, int p, int r,int i) {
		int[] copy = Arrays.copyOf(a, a.length);//make a copy to be non destructive to original array
		
		if(p==r)
			return copy[p];
		int z = randomInt(p,r);
		int temp = copy[z];
		//swap
		copy[z]= copy[r];
		copy[r] = temp;
		
		int q = partition(copy, p, r);
		int k = q-p+1;
		if (i == k)
			return copy[q];
		else if(i<k)
			return randomizedQuickselect(copy,p,q-1,i);
		else
			return randomizedQuickselect(copy,q+1,r,i-k);
	}
	
	// Get a random index number and swap it with the right most index in the array
		// random number index value is the pivot
		public static int randomInt(int start, int end){
			Random ran = new Random();
			int rando = ran.nextInt(end-start)+start;
			return rando;
				}
		
		//takes the last element and moves all smaller to the left in the array
		private static int partition(int[]array, int start, int end) {
			int x = array[end];
			int i = start-1;//index to be switched with larger
			
			//loop to compare pivot to array elements and switch if smaller
			for(int j = start; j<=end-1;j++) {
				if(array[j]< x) {
					i = i + 1;
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}						
			}
			//move the pivot to the middle/where its supposed to be in order
			int temp = array[i+1];
			array[i+1] = array[end];
			array[end] = temp;
			return i + 1;		
		}
		
		//toString method to print each index in the array
		public static String toString(int []ary) {
			String copy = "";
			int length = ary.length;
			for(int i = 0;i<length; i++) {
				copy += ary[i]+" "; 
			}
			return copy;		
		}
	
	public static void main(String[] args) {
		int [] arrayCS1 = {2,5,3,0,2,3,0,3};
		int [] arrayCS1b = new int [arrayCS1.length];
		System.out.println("1)Original Array   \t"+toString(arrayCS1));
		countingSort(arrayCS1,arrayCS1b,5);
		System.out.println("After CountingSort\t"+toString(arrayCS1b));
		
		int [] arrayCS2 = {2,15,1,14,2,6,0,2,11,9,9,15};
		int [] arrayCS2b = new int [arrayCS2.length];
		System.out.println("2)Original Array   \t"+toString(arrayCS2));
		countingSort(arrayCS2,arrayCS2b,15);
		System.out.println("After CountingSort\t"+toString(arrayCS2b));
		
		int [] arrayCS3 = {543,582,790,93,16,999,989,777,431,444,0,0,0};
		int [] arrayCS3b = new int [arrayCS3.length];
		System.out.println("3)Original Array   \t"+toString(arrayCS3));
		countingSort(arrayCS3,arrayCS3b,1000);
		System.out.println("After CountingSort\t"+toString(arrayCS3b));
		
		int [] arrayCS4 = {66,56,43,88,96,34,21,18,25,100,8};
		int [] arrayCS4b = new int [arrayCS4.length];
		System.out.println("4)Original Array   \t"+toString(arrayCS4));
		countingSort(arrayCS4,arrayCS4b,100);
		System.out.println("After CountingSort\t"+toString(arrayCS4b));
		
		int [] arrayCS5 = {87,355,47,33,123,89,0,0,300,2};
		int [] arrayCS5b = new int [arrayCS5.length];
		System.out.println("5)Original Array   \t"+toString(arrayCS5));
		countingSort(arrayCS5,arrayCS5b,355);
		System.out.println("After CountingSort\t"+toString(arrayCS5b));
		
		System.out.println("=================================================");
		
		int [] arrayQS1 = {6,22,11,56,47,99,81,1,200,312,4,555};
		System.out.println("1)Original Array  \t"+toString(arrayQS1));
		System.out.println("Quick-Select Order Statistic:1    \t"+randomizedQuickselect(arrayQS1,0,arrayQS1.length-1,1));
		System.out.println("Nondestroyed Array\t"+toString(arrayQS1));
		
		int [] arrayQS2 = {2,15,1,14,2,6,0,2,11,9,9,15};
		System.out.println("2)Original Array  \t"+toString(arrayQS2));
		System.out.println("Quick-Select Order Statistic:12    \t"+randomizedQuickselect(arrayQS2,0,arrayQS2.length-1,12));
		System.out.println("Nondestroyed Array\t"+toString(arrayQS2));
		
		int [] arrayQS3 = {543,582,790,93,16,999,989,777,431,444,0,0,0};
		System.out.println("3)Original Array  \t"+toString(arrayQS3));
		System.out.println("Quick-Select Order Statistic:7    \t"+randomizedQuickselect(arrayQS3,0,arrayQS3.length-1,7));
		System.out.println("Nondestroyed Array\t"+toString(arrayQS3));
		
		int [] arrayQS4 = {66,56,43,88,96,34,21,18,25,100,8};
		System.out.println("4)Original Array  \t"+toString(arrayQS4));
		System.out.println("Quick-Select Order Statistic:6    \t"+randomizedQuickselect(arrayQS4,0,arrayQS4.length-1,6));
		System.out.println("Nondestroyed Array\t"+toString(arrayQS4));
		
		int [] arrayQS5 = {87,355,47,33,123,89,0,0,300,2};
		System.out.println("5)Original Array  \t"+toString(arrayQS5));
		System.out.println("Quick-Select Order Statistic:3   \t"+randomizedQuickselect(arrayQS5,0,arrayQS5.length-1,3));
		System.out.println("Nondestroyed Array\t"+toString(arrayQS5));

	}

}
